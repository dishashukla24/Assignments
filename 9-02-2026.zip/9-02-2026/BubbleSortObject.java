class BubbleSortObject {
    String name;
    int rollno;

    public BubbleSortObject(int rollno, String name) {
        this.rollno = rollno;
        this.name = name;
        
    }

    public String toString() {
        return rollno + " : " + name;
    }

    public static void main(String[] args) {

        BubbleSortObject[] b = {
            new BubbleSortObject(8, "Ram"),
            new BubbleSortObject(5, "Ishaan"),
            new BubbleSortObject(1, "Raghav"),
            new BubbleSortObject(6, "Sachin"),
            new BubbleSortObject(4, "Isha")
        };

        int n = b.length;

       
        for (int i = 0; i < n - 1; i++) {
            boolean flag = false;

            for (int j = 0; j < n - 1 - i; j++) {

                if (b[j].rollno > (b[j + 1].rollno)) {

                    BubbleSortObject temp = b[j];
                    b[j] = b[j + 1];
                    b[j + 1] = temp;

                    flag = true;
                }
            }

            if (!flag)
                break;
        }

        for (BubbleSortObject obj : b) {
            System.out.println(obj);
        }
    }
}
