

public class VivaAnswers {
    /*
1. Amortized Time Complexity:
   Average time taken over multiple operations.

2. Why ArrayList resizing is expensive?
   Because new array is created and old elements are copied.

3. How LinkedList stores elements?
   As nodes containing data and reference to next node.

4. Singly vs Doubly Linked List:
   Singly → one pointer
   Doubly → two pointers (prev + next)

5. Space complexity of LinkedList:
   Higher than ArrayList due to extra node references.
     */

    
}
