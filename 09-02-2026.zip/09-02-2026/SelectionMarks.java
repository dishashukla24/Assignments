class Student {
    int mark1;
    int mark2;
    int mark3;
    String name;

    Student(int m1, int m2, int m3, String n) {
        mark1 = m1;
        mark2 = m2;
        mark3 = m3;
        name = n;
    }

    @Override
    public String toString() {
        return mark1 + " " + mark2 + " " + mark3 + " " + name;
    }
}

public class SelectionMarks {
    public static void main(String[] args) {

        Student[] arr = {
            new Student(80, 70, 60, "A"),
            new Student(80, 70, 50, "B"),
            new Student(80, 60, 90, "C"),
            new Student(75, 90, 95, "D"),
            new Student(80, 70, 60, "E")
        };

        int n = arr.length;

        for (int i = 0; i < n - 1; i++) {

            int mini = i;

            for (int j = i + 1; j < n; j++) {

                if (arr[j].mark1 < arr[mini].mark1)
                    mini = j;

                else if (arr[j].mark1 == arr[mini].mark1 &&
                         arr[j].mark2 < arr[mini].mark2)
                    mini = j;

                else if (arr[j].mark1 == arr[mini].mark1 &&
                         arr[j].mark2 == arr[mini].mark2 &&
                         arr[j].mark3 < arr[mini].mark3)
                    mini = j;
            }

            Student temp = arr[mini];
            arr[mini] = arr[i];
            arr[i] = temp;
        }

        for (Student s : arr) {
            System.out.println(s);
        }
    }
}
