class Student {
    int mark1;
    int mark2;
    int mark3;
    String name;

    Student(int m1, int m2, int m3, String n) {
        mark1 = m1;
        mark2 = m2;
        mark3 = m3;
        name = n;
    }

    @Override
    public String toString() {
        return mark1 + " " + mark2 + " " + mark3 + " " + name;
    }
}

public class InsertionMarks {
    public static void main(String[] args) {

        Student[] arr = {
            new Student(80, 70, 60, "A"),
            new Student(80, 70, 50, "B"),
            new Student(80, 60, 90, "C"),
            new Student(75, 90, 95, "D"),
            new Student(80, 70, 60, "E")
        };

        int n = arr.length;

        // Insertion Sort
        for (int i = 1; i < n; i++) {

            Student key = arr[i];
            int j = i - 1;

            while (j >= 0) {

                boolean move = false;

                if (arr[j].mark1 > key.mark1)
                    move = true;
                else if (arr[j].mark1 == key.mark1 &&
                         arr[j].mark2 > key.mark2)
                    move = true;
                else if (arr[j].mark1 == key.mark1 &&
                         arr[j].mark2 == key.mark2 &&
                         arr[j].mark3 > key.mark3)
                    move = true;

                if (!move)
                    break;

                arr[j + 1] = arr[j];
                j--;
            }

            arr[j + 1] = key;
        }

        for (Student s : arr) {
            System.out.println(s);
        }
    }
}
