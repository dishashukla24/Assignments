
import java.util.Arrays;

class Student6 {
    int[] markn;
    
    String name;

    Student6(int[] marks, String n) {
        markn = marks;
        name = n;
    }
    @Override
    public String toString() {
        return Arrays.toString(markn) + " " + name;
    }
}

public class NNumberOfMarks {
    public static void main(String[] args) {
        Student6[] arr = {
            new Student6(new int[] {23,44,56}, "A"),
            new Student6(new int[] {24,46,56}, "B"),
            new Student6(new int[] {27,41,57}, "C"),
            new Student6(new int[] {23,42,59}, "D"),
            new Student6(new int[] {23,44,59}, "E")
        };

       
    
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {

                boolean swap = false;
//
              
                int k=0;
                while(k<3) {
                	if(arr[j].markn[k]>arr[j+1].markn[k]) {
                		swap=true;
                		break;
                	}
                	if(arr[j].markn[k]<arr[j+1].markn[k]) break;
                	k++;
                }

                if (swap) {
                    Student6 temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        for (Student6 arr1 : arr) {
            System.out.println(arr1);
        }
     
    }
}