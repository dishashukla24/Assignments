import java.util.Arrays;

class Student6 {
    int[] markn;
    String name;

    Student6(int[] marks, String n) {
        markn = marks;
        name = n;
    }

    @Override
    public String toString() { 
        return Arrays.toString(markn) + " " + name;
    }
}

public class InsertionNMarks {
    public static void main(String[] args) {

        Student6[] arr = {
            new Student6(new int[] {23,44,56}, "A"),
            new Student6(new int[] {24,46,56}, "B"),
            new Student6(new int[] {27,41,57}, "C"),
            new Student6(new int[] {23,42,59}, "D"),
            new Student6(new int[] {23,44,59}, "E")
        };

        int n = arr.length;
        int m = arr[0].markn.length; // number of subjects

        // Insertion Sort
        for (int i = 1; i < n; i++) {

            Student6 key = arr[i];
            int j = i - 1;

            while (j >= 0) {

                boolean move = false;
                int k = 0;

                while (k < m) {
                    if (arr[j].markn[k] > key.markn[k]) {
                        move = true;
                        break;
                    }
                    if (arr[j].markn[k] < key.markn[k]) {
                        break;
                    }
                    k++;
                }

                if (!move) break;

                arr[j + 1] = arr[j];
                j--;
            }

            arr[j + 1] = key;
        }

        for (Student6 s : arr) {
            System.out.println(s);
        }
    }
}
