class InsertionObject {
    String name;
    int rollno;

    public InsertionObject(int rollno, String name) {
        this.rollno = rollno;
        this.name = name;
    }

    @Override
    public String toString() {
        return rollno + " : " + name;
    }

    public static void main(String[] args) {

        InsertionObject[] b = {
            new InsertionObject(8, "Ram"),
            new InsertionObject(5, "Ishaan"),
            new InsertionObject(1, "Raghav"),
            new InsertionObject(6, "Sachin"),
            new InsertionObject(4, "Isha")
        };

        int n = b.length;

        for (int i = 1; i < n; i++) {

            InsertionObject key = b[i];
            int j = i - 1;

            while (j >= 0 && b[j].rollno > key.rollno) {
                b[j + 1] = b[j];
                j--;
            }

            b[j + 1] = key;
        }

        for (InsertionObject obj : b) {
            System.out.println(obj);
        }
    }
}
