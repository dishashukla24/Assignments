class SelectionSortObject {
    String name;
    int rollno;

    public SelectionSortObject(int rollno, String name) {
        this.rollno = rollno;
        this.name = name;
    }
    @Override
    public String toString() {
        return rollno + " : " + name;
    }

    public static void main(String[] args) {

        SelectionSortObject[] b = {
            new SelectionSortObject(8, "Ram"),
            new SelectionSortObject(5, "Ishaan"),
            new SelectionSortObject(1, "Raghav"),
            new SelectionSortObject(6, "Sachin"),
            new SelectionSortObject(4, "Isha")
        };

        int n = b.length;

        for (int i = 0; i < n - 1; i++) {

            int mini = i;

            for (int j = i + 1; j < n; j++) {
                if (b[j].rollno < b[mini].rollno) {
                    mini = j;
                }
            }

            SelectionSortObject temp = b[mini];
            b[mini] = b[i];
            b[i] = temp;
        }

        for (SelectionSortObject obj : b) {
            System.out.println(obj);
        }
    }
}
